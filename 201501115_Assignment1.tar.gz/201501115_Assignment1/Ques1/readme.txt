1.) index longlist
2.) index shortlist <mtime1> <mtime2> that will be printed in longlist command
3.) hash checkall
4.) hash verify <filename>
5.) download <filename> (TCP download implemented)
